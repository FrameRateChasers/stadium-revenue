﻿Public Class Form1

    'Jeffrey hagan
    'vb for busness
    'Stadium

    'private varuable   
    Private Const PRICE_OF_A As Integer = 15
    Private Const PRICE_OF_B As Integer = 12
    Private Const PRICE_OF_C As Integer = 9

    'public variables that will store everything
    Public intCA, intCB, intCC, intResults, intResultA, intResultB, intResultC As Integer


    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        'this will clear all text and data
        lblCA.Text = ""
        lblCB.Text = ""
        lblCC.Text = ""
        lblOutputRev.Text = ""
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        'close the form
        Me.Close()

    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click

        ' first converts textbox input into integer 
        'then it is stored in global variables above
        intCA = CInt(TextBox1.Text)
        intCB = CInt(TextBox2.Text)
        intCC = CInt(TextBox3.Text)

        'mulitply a VARIABLE and CONSTANT
        'then stores the result into another set of global varible
        intResultA = intCA * PRICE_OF_A
        intResultB = intCB * PRICE_OF_B
        intResultC = intCC * PRICE_OF_C

        'global varible is then converted into string with currency format
        'and is store in label and dispplays as text
        lblCA.Text = intResultA.ToString("c")
        lblCB.Text = intResultB.ToString("c")
        lblCC.Text = intResultC.ToString("c")

        'add all the results and display all calucation 
        intResults = intResultA + intResultB + intResultC
        lblOutputRev.Text = intResults.ToString("c")

    End Sub

End Class